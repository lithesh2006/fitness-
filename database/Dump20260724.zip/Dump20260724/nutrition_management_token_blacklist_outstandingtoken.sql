-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: nutrition_management
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `token_blacklist_outstandingtoken`
--

DROP TABLE IF EXISTS `token_blacklist_outstandingtoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `token_blacklist_outstandingtoken` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `token` longtext NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `expires_at` datetime(6) NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `jti` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_blacklist_outstandingtoken_jti_hex_d9bdf6f7_uniq` (`jti`),
  KEY `token_blacklist_outstandingtoken_user_id_83bc629a_fk_Users_id` (`user_id`),
  CONSTRAINT `token_blacklist_outstandingtoken_user_id_83bc629a_fk_Users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token_blacklist_outstandingtoken`
--

LOCK TABLES `token_blacklist_outstandingtoken` WRITE;
/*!40000 ALTER TABLE `token_blacklist_outstandingtoken` DISABLE KEYS */;
INSERT INTO `token_blacklist_outstandingtoken` VALUES (1,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc4NTQ2MzQ2MSwiaWF0IjoxNzg0ODU4NjYxLCJqdGkiOiI5OGM3MWJmNTE5NzQ0OTM4OTVjYjYwNjkwZjc1MjYyZSIsInVzZXJfaWQiOiIxIn0.k-tvrGOLJbBm0-csj90Mk4YNIsiQ4TqW0vA7Rj6c3N0','2026-07-24 02:04:21.118710','2026-07-31 02:04:21.000000',1,'98c71bf51974493895cb60690f75262e'),(2,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc4NTQ2NDMxMSwiaWF0IjoxNzg0ODU5NTExLCJqdGkiOiI4NjhiZDM3NDQ5Y2E0MWRmYWFiYzM2NTJiNjRlMzE0OSIsInVzZXJfaWQiOiIxIn0.Kji_7jO5uZM8CbcMtwY44HAjbktpRQP_sPzwGJEeX1o','2026-07-24 02:18:31.297870','2026-07-31 02:18:31.000000',1,'868bd37449ca41dfaabc3652b64e3149'),(3,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc4NTQ3NjAxMywiaWF0IjoxNzg0ODcxMjEzLCJqdGkiOiJlN2YyOWZlMmFmZjI0YWE3YThmZGMyNDk1YjUwODc4MCIsInVzZXJfaWQiOiIxIn0.ZqG-Zod4ovGDJkMAjnzh3zeNpCE2ekF-BHVLhFo98eE','2026-07-24 05:33:33.423316','2026-07-31 05:33:33.000000',1,'e7f29fe2aff24aa7a8fdc2495b508780'),(4,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc4NTIzOTI5NywiaWF0IjoxNzg0NjM0NDk3LCJqdGkiOiJhYzgzZmNhYjI3ZTk0ZDU5OTFhMWRiMjE5YmE1NDRmNyIsInVzZXJfaWQiOiIxIn0.zz5vE5YrPtR_RCyVqUhSVhsvlocK2g5CWZhjYhmDJLE','2026-07-24 05:54:25.618792','2026-07-28 11:48:17.000000',1,'ac83fcab27e94d5991a1db219ba544f7'),(6,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc4NTQ3NzI2NSwiaWF0IjoxNzg0ODcyNDY1LCJqdGkiOiI5ZDFkYjY4MDI2YmM0ODdkYWMxZGNlMjU5NmRiMmE1MSIsInVzZXJfaWQiOiIxIn0.CXt6TmwBQv83qB_urYjNQLjU3R1J-R8t4aa7x0UXeNE','2026-07-24 05:54:25.618792','2026-07-31 05:54:25.000000',1,'9d1db68026bc487dac1dce2596db2a51'),(7,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc4NTQ3NzI2NSwiaWF0IjoxNzg0ODcyNDY1LCJqdGkiOiI5MzJiZDM3ZTA0NTY0ZjhlOGMzODg5YjdkMDFlNDhmNCIsInVzZXJfaWQiOiIxIn0.xfFBfj1FBSolRFjTf2BG_NHXAyyjPuly-PaSdN6EX1g','2026-07-24 05:54:25.622542','2026-07-31 05:54:25.000000',1,'932bd37e04564f8e8c3889b7d01e48f4'),(8,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc4NTQ3ODA4NiwiaWF0IjoxNzg0ODczMjg2LCJqdGkiOiI5MzJlZGVmYjg3NGI0ODQ3YmMyMzdmMDdhZGM5ZTQ5NCIsInVzZXJfaWQiOiIxIn0.IvuIYM-y-SN07sTvwZ0ZVeOIuLfKMY_-KGDHjBFe1xI','2026-07-24 06:08:06.732348','2026-07-31 06:08:06.000000',1,'932edefb874b4847bc237f07adc9e494');
/*!40000 ALTER TABLE `token_blacklist_outstandingtoken` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-24 13:15:46
